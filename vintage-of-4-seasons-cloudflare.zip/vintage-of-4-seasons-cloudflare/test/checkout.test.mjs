// Run with:  node test/checkout.test.mjs
// Uses a pretend Stripe, so nothing is charged. Every line should say PASS.
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const tmp = path.join(os.tmpdir(), 'checkout-under-test.mjs');
fs.copyFileSync(path.join(here, '../functions/api/checkout.js'), tmp);
const { onRequest } = await import(pathToFileURL(tmp).href);

let sent = null, mode = 'ok';
globalThis.fetch = async (url, init) => {
  sent = { url, init, form: new URLSearchParams(init.body) };
  if (mode === 'down') throw new Error('network down');
  if (mode === 'reject') return new Response(JSON.stringify({ error: { message: 'bad' } }), { status: 400 });
  return new Response(JSON.stringify({ url: 'https://checkout.stripe.com/c/pay/TEST' }), { status: 200 });
};
const env = { STRIPE_SECRET_KEY: 'sk_test_x', SITE_URL: 'https://example-shop.com' };
const get = (qs, e = env) => onRequest({ request: new Request('https://shop.test/api/checkout?' + new URLSearchParams(qs)), env: e });
const cart = (rows) => JSON.stringify(rows);
const amounts = () => [...sent.form.entries()].filter(([k]) => k.endsWith('[unit_amount]')).map(([, v]) => Number(v));
let failed = 0;
const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) failed++; };

let r = await get({ cart: cart([['Handcrafted Winter Angel', 'Red', 2], ['Medallion Ornament', 'Cream · Large', 1]]), zip: '90210', email: 'a@b.co' });
check('normal cart redirects to Stripe', r.status === 303 && r.headers.get('Location').startsWith('https://checkout.stripe.com/'));
check('prices and shipping are right (8500, 12500, 750)', JSON.stringify(amounts()) === '[8500,12500,750]', JSON.stringify(amounts()));
check('request goes to Stripe with the secret key', sent.url === 'https://api.stripe.com/v1/checkout/sessions' && sent.init.headers.Authorization === 'Bearer sk_test_x');
check('shipping address + phone collected, US only', sent.form.get('shipping_address_collection[allowed_countries][0]') === 'US' && sent.form.get('phone_number_collection[enabled]') === 'true');
check('success/cancel links use SITE_URL', sent.form.get('success_url') === 'https://example-shop.com?paid=1' && sent.form.get('cancel_url') === 'https://example-shop.com');
r = await get({ cart: cart([['Handcrafted Winter Angel', 'Red', 1, 0.01]]), zip: '10001' });
check('a price sent by the browser is ignored', amounts()[0] === 8500, String(amounts()[0]));
for (const [label, c] of [['unknown product', [['Fake Item', 'Red', 1]]], ['negative quantity', [['Cross Ornament', 'Red', -5]]], ['fractional quantity', [['Cross Ornament', 'Red', 1.5]]], ['quantity over 50', [['Cross Ornament', 'Red', 51]]], ['unknown size', [['Medallion Ornament', 'Red · Giant', 1]]], ['size = constructor', [['Medallion Ornament', 'Red · constructor', 1]]], ['name = __proto__', [['__proto__', 'Red · toString', 1]]], ['name = constructor', [['constructor', 'Red', 1]]], ['name is a number', [[5, 'Red', 1]]]]) {
  r = await get({ cart: cart(c) }); check(label + ' -> 400', r.status === 400);
}
r = await get({ cart: 'not json' }); check('bad JSON -> 400', r.status === 400);
r = await get({}); check('no cart -> 400', r.status === 400);
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'POST', body: '{bad json' }), env }); check('broken POST body -> 400', r.status === 400);
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'POST', body: JSON.stringify({ cart: [['Cross Ornament', 'Red', 1]] }) }), env });
check('POST returns the Stripe link as JSON', r.status === 200 && (await r.json()).url.includes('checkout.stripe.com'));
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'DELETE' }), env }); check('other methods -> 405', r.status === 405);
r = await get({ cart: cart([['Cross Ornament', 'Red', 1]]) }, { SITE_URL: 'https://x.com' }); check('missing Stripe key -> 500', r.status === 500);
r = await get({ cart: cart([['Cross Ornament', 'Red', 1]]) }, { STRIPE_SECRET_KEY: 'sk_test_x' }); check('missing SITE_URL -> 500', r.status === 500);
r = await get({ cart: cart([['Cross Ornament', 'Red', 1]]) }, { STRIPE_SECRET_KEY: 'sk_test_x', SITE_URL: 'example.com' }); check('SITE_URL without https -> 500', r.status === 500);
mode = 'reject'; r = await get({ cart: cart([['Cross Ornament', 'Red', 1]]) }); check('Stripe says no -> friendly 500', r.status === 500);
mode = 'down'; r = await get({ cart: cart([['Cross Ornament', 'Red', 1]]) }); check('Stripe unreachable -> friendly 500', r.status === 500);
mode = 'ok';
await get({ cart: cart([['Cross Ornament', 'Red', 1], ['Guitar Ornament', 'Red', 1]]), zip: '90001' });
check('shipping for 2 lines, ZIP 9xxxx = 750 cents', amounts().at(-1) === 750, String(amounts().at(-1)));
console.log(failed ? '\n' + failed + ' check(s) FAILED' : '\nAll checks passed');
process.exit(failed ? 1 : 0);
