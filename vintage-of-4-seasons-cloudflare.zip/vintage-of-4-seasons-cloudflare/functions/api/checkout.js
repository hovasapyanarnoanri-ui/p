// functions/api/checkout.js  —  Cloudflare Pages Function for Vintage of 4 Seasons
// It answers at the web address  /api/checkout
//
// The website sends the CART (product names, colors/sizes, quantities) — NEVER prices.
// This file looks up the real prices below, so a customer can't change what they pay,
// then asks Stripe for a hosted checkout page and sends the customer there.
// No extra libraries needed: it talks to Stripe's web API directly.
//
// Settings (Cloudflare dashboard > your Pages project > Settings > Variables and secrets):
//   STRIPE_SECRET_KEY  your Stripe secret key (starts with sk_test_ or sk_live_)  <- make it a Secret
//   SITE_URL           your real site address, starting with https://

// ---------------------------------------------------------------
// PRICE LIST (US dollars). When Luso changes a price, change it here AND on the website.
// ---------------------------------------------------------------
const CATALOG = {
  "Handcrafted Winter Angel": {"p":85},
  "Vintage Carousel Horse Drum Ornament": {"p":75},
  "Gold Leaf Teardrop Ornament": {"p":60},
  "Antique Carriage Ornament": {"p":125},
  "Guitar Ornament": {"p":80},
  "Chandelier Ornament": {"p":115},
  "High Heel Ornament": {"p":25,"sizes":{"Single Shoe":25,"Pair":45}},
  "Medallion Ornament": {"p":85,"sizes":{"Small":85,"Medium":105,"Large":125}},
  "Mother Mary Ornament": {"p":80},
  "Doves & Crown Ornament": {"p":80},
  "Throne Ornament": {"p":75},
  "Peacock Ornament": {"p":115},
  "Ornament Gift Box": {"p":190,"sizes":{"Small":190,"Medium":315,"Large":510}},
  "Jeweled Bow Ornament": {"p":85},
  "Cross Ornament": {"p":85},
  "Mother Mary and Baby Jesus Ornament": {"p":85},
};

const has = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);

// Price for a product + variant. Variants look like "Red" or "Cream · Large";
// for products with sizes, the text after the last " · " picks the price.
function priceFor(name, variant) {
  if (!has(CATALOG, name)) return null;
  const item = CATALOG[name];
  if (item.sizes) {
    const size = String(variant).split(' · ').pop();
    return has(item.sizes, size) ? item.sizes[size] : null;
  }
  return item.p;
}

// Same ZIP-based shipping estimate the website shows. lineCount = number of different cart lines.
function shippingCost(lineCount, zip) {
  const base = 6, perExtra = 1.5, extra = (lineCount - 1) * perExtra;
  const digit = zip ? Number(zip[0]) : null;
  let zoneFee = 3;
  if (digit !== null) zoneFee = Math.round(Math.abs(9 - digit) * 0.9 * 10) / 10;
  return Math.round((base + extra + zoneFee) * 100) / 100;
}

const clean = (v, max) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max) : '');
const say = (message, status) =>
  new Response(message, { status, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });

export async function onRequest(context) {
  const { request, env } = context;

  if (request.method !== 'GET' && request.method !== 'POST') return say('Method not allowed', 405);
  if (!env.STRIPE_SECRET_KEY) return say('Server misconfiguration: STRIPE_SECRET_KEY is missing.', 500);
  const siteUrl = env.SITE_URL;
  if (!siteUrl || !/^https?:\/\//.test(siteUrl)) {
    return say('Server misconfiguration: SITE_URL is missing or must start with https://', 500);
  }

  // Read the details (address bar for GET, JSON body for POST)
  let q;
  if (request.method === 'GET') {
    const p = new URL(request.url).searchParams;
    q = { cart: p.get('cart'), zip: p.get('zip'), email: p.get('email'), name: p.get('name'), phone: p.get('phone'), addr: p.get('addr') };
  } else {
    try { q = await request.json(); } catch (e) { return say('Invalid request body.', 400); }
    if (!q || typeof q !== 'object') return say('Invalid request body.', 400);
  }

  let cart;
  try { cart = typeof q.cart === 'string' ? JSON.parse(q.cart) : q.cart; } catch (e) { cart = null; }
  if (!Array.isArray(cart) || cart.length < 1 || cart.length > 30) {
    return say('Your cart looks empty. Please go back and try again.', 400);
  }

  // Build the form Stripe expects (every price comes from CATALOG above)
  const form = new URLSearchParams();
  form.append('mode', 'payment');
  let n = 0;
  for (const row of cart) {
    const [name, variant, qty] = Array.isArray(row) ? row : [];
    const price = typeof name === 'string' ? priceFor(name, variant) : null;
    const quantity = Number(qty);
    if (price === null || !Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
      return say('One of the items in your cart could not be found. Please go back and try again.', 400);
    }
    form.append(`line_items[${n}][price_data][currency]`, 'usd');
    form.append(`line_items[${n}][price_data][product_data][name]`, clean(name, 100) + ' — ' + clean(String(variant), 60));
    form.append(`line_items[${n}][price_data][unit_amount]`, String(Math.round(price * 100)));
    form.append(`line_items[${n}][quantity]`, String(quantity));
    n++;
  }

  const zip = /^\d{5}$/.test(clean(q.zip, 5)) ? clean(q.zip, 5) : '';
  const ship = shippingCost(cart.length, zip);
  form.append(`line_items[${n}][price_data][currency]`, 'usd');
  form.append(`line_items[${n}][price_data][product_data][name]`, 'Shipping (estimate)');
  form.append(`line_items[${n}][price_data][unit_amount]`, String(Math.round(ship * 100)));
  form.append(`line_items[${n}][quantity]`, '1');

  const email = clean(q.email, 200);
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) form.append('customer_email', email);
  form.append('shipping_address_collection[allowed_countries][0]', 'US');
  form.append('phone_number_collection[enabled]', 'true');
  form.append('metadata[name]', clean(q.name, 200));
  form.append('metadata[phone]', clean(q.phone, 40));
  form.append('metadata[address]', clean(q.addr, 300));
  form.append('metadata[zip]', zip);
  form.append('success_url', siteUrl + (siteUrl.includes('?') ? '&' : '?') + 'paid=1');
  form.append('cancel_url', siteUrl);

  // Ask Stripe for the hosted checkout page
  let data = {};
  let ok = false;
  try {
    const resp = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + env.STRIPE_SECRET_KEY, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(),
    });
    data = await resp.json().catch(() => ({}));
    ok = resp.ok && !!data.url;
    if (!ok) console.error('Stripe error', resp.status, data && data.error && data.error.message);
  } catch (e) {
    console.error('Could not reach Stripe', e && e.message);
  }
  if (!ok) return say('Something went wrong starting checkout. Please go back and try again.', 500);

  if (request.method === 'POST') {
    return new Response(JSON.stringify({ url: data.url }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }
  return new Response(null, { status: 303, headers: { Location: data.url } });
}
